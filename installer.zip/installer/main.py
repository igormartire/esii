from chess.ui import ui

ui.run()
